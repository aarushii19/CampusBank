# Bank Management System — Submission and Demonstration Guide

## Project scope

This is an academic banking simulation with sample data. It demonstrates customer/branch/account management, deposits, withdrawals, transfers, loan records and repayments, SQL reports, referential integrity, and transaction rollback. It is not intended for real banking use. Authentication and authorization are not implemented.

The detailed Phase 1 scope, ER diagram, relational schema, and normalization rationale are in [PHASE1_DATABASE_DESIGN.md](./PHASE1_DATABASE_DESIGN.md). The complete database DDL, seed data, view, stored procedure, trigger, and sample SQL are in [bank_management.sql](./bank_management.sql).

## Fresh database setup

1. Install MySQL 8.0 or later and open a MySQL client.
2. Run `mysql -u root -p < bank_management.sql`, or open and execute the script in MySQL Workbench.
3. **The script drops and recreates the `bank_management` database. Back up any existing database with that name before running it.**
4. Copy `backend/.env.example` to `backend/.env` and enter the local MySQL host, port, username, password, and database name.
5. From `backend/`, run `npm ci` and `npm start`. Confirm `GET http://localhost:3001/api/health` succeeds.
6. From `frontend/`, run `npm ci` and `npm run dev`; open `http://localhost:5173`.

For a fresh demonstration, use the included seed records. Show the dashboard, search a customer, inspect an account, post a deposit and withdrawal, transfer between two active accounts, view transaction history and reports, then record a loan repayment. Verify balances and ledger entries after each operation. Try a withdrawal or transfer above the available balance and an invalid account ID; the API should reject each request and preserve balances and ledger rows.

## Verification record

- Backend automated suite: 10 tests passed. It covers request validation, parameterized transaction filtering, customer CRUD, transfer lock ordering, successful deposit/transfer paths, inactive/invalid accounts, and insufficient-funds rollback using a fake MySQL pool/connection.
- Frontend production build: completed successfully with the project's Rollup configuration.
- Browser evidence: dashboard preview captured with deterministic fixture responses intercepted in the browser. It confirms the dashboard layout and representative display only; it is not evidence of a live API or MySQL session.
- Live DB integration: not verified in this environment. The MySQL80 service was running, but the available `root` connection without a password was rejected. No SQL execution or real database query output is claimed. Configure valid local credentials and follow the fresh database steps to complete the live demonstration.

See `evidence/screenshots/` for the available screenshot. Capture remaining screens and actual SQL outputs during the live demonstration after configuring credentials.

## Viva preparation

1. **Why use 3NF?** Each table models one entity or relationship; non-key attributes depend on the key, the whole key, and nothing but the key. This reduces repeated facts and update anomalies.
2. **How is the ER model connected?** Customers and branches each relate one-to-many to accounts; customers and branches each relate one-to-many to loans; loans relate one-to-many to payments; accounts relate to transaction source and optional destination; a repayment can link to its ledger transaction.
3. **How is current balance obtained?** `AccountSummaryView` derives it from the opening balance and posted ledger activity, so the ledger remains the source of truth.
4. **How does a transfer stay atomic?** The API begins a DB transaction, locks both account rows in ascending ID order, validates active status and funds, writes both ledger sides, and commits. Exceptions roll back all writes.
5. **Why lock rows and order locks?** `SELECT ... FOR UPDATE` serializes competing balance changes. A consistent lock order lowers deadlock risk when two transfers touch the same accounts in opposite directions.
6. **How are invalid data and injection addressed?** Database keys/checks/unique constraints enforce integrity; request validation checks input; values use parameterized SQL, and dynamic identifiers use fixed allowlists.
7. **What does the trigger/procedure/view demonstrate?** The trigger validates or audits ledger changes, the stored procedure demonstrates a database-side transfer workflow, and the view exposes joined/aggregated account balances.
8. **What is outside scope?** This sample application has no real payment rails, authentication, authorization, compliance controls, or production security hardening.

## Suggested live query evidence

In MySQL Workbench, run `SELECT * FROM AccountSummaryView;`, a grouped transaction `COUNT`/`SUM` report, and a loan `AVG`/`GROUP BY` report from the SQL script. Capture the result grids with the executed query visible. The current package does not contain live query screenshots because the database credentials were unavailable during preparation.
