const express = require('express');
const { HttpError, asyncRoute, errorHandler } = require('./errors');
const { positiveId, requiredString, positiveAmount, nonNegativeAmount, enumValue, hasOnly } = require('./validation');
const { postDepositOrWithdrawal, transferFunds, createLoanPayment } = require('./operations');

const resourceDefinitions = {
  customers: {
    table: 'customers', id: 'customer_id',
    fields: ['first_name', 'last_name', 'email', 'phone', 'date_of_birth', 'address'],
    required: ['first_name', 'last_name', 'email'],
    validate: {
      first_name: (v) => requiredString(v, 'first_name', 80),
      last_name: (v) => requiredString(v, 'last_name', 80),
      email: (v) => requiredString(v, 'email', 254),
      phone: (v) => v == null ? null : requiredString(v, 'phone', 32),
      date_of_birth: (v) => v == null ? null : v,
      address: (v) => v == null ? null : requiredString(v, 'address', 500)
    }
  },
  branches: {
    table: 'branches', id: 'branch_id',
    fields: ['branch_code', 'name', 'address', 'phone'],
    required: ['branch_code', 'name', 'address'],
    validate: {
      branch_code: (v) => requiredString(v, 'branch_code', 20),
      name: (v) => requiredString(v, 'name', 120),
      address: (v) => requiredString(v, 'address', 500),
      phone: (v) => v == null ? null : requiredString(v, 'phone', 32)
    }
  },
  accounts: {
    table: 'accounts', id: 'account_id',
    fields: ['customer_id', 'branch_id', 'account_number', 'account_type', 'opening_balance', 'opened_on', 'status'],
    required: ['customer_id', 'branch_id', 'account_number', 'account_type'],
    validate: {
      customer_id: (v) => positiveId(v, 'customer_id'),
      branch_id: (v) => positiveId(v, 'branch_id'),
      account_number: (v) => requiredString(v, 'account_number', 34),
      account_type: (v) => enumValue(v, ['checking', 'savings', 'fixed_deposit'], 'account_type'),
      opening_balance: (v) => v == null ? '0.00' : nonNegativeAmount(v, 'opening_balance'),
      opened_on: (v) => v == null ? new Date().toISOString().slice(0, 10) : v,
      status: (v) => v == null ? 'active' : enumValue(v, ['active', 'frozen', 'closed'], 'status')
    }
  },
  loans: {
    table: 'loans', id: 'loan_id',
    fields: ['customer_id', 'branch_id', 'loan_number', 'principal_amount', 'annual_interest_rate', 'term_months', 'issued_on', 'due_on', 'status'],
    required: ['customer_id', 'branch_id', 'loan_number', 'principal_amount', 'term_months', 'issued_on', 'due_on'],
    validate: {
      customer_id: (v) => positiveId(v, 'customer_id'),
      branch_id: (v) => positiveId(v, 'branch_id'),
      loan_number: (v) => requiredString(v, 'loan_number', 34),
      principal_amount: (v) => positiveAmount(v, 'principal_amount'),
      annual_interest_rate: (v) => {
        const n = Number(v ?? 0);
        if (!Number.isFinite(n) || n < 0 || n > 999.9999) throw new HttpError(400, 'annual_interest_rate must be between 0 and 999.9999', 'VALIDATION_ERROR');
        return n.toFixed(4);
      },
      term_months: (v) => positiveId(v, 'term_months'),
      issued_on: (v) => v,
      due_on: (v) => v,
      status: (v) => v == null ? 'active' : enumValue(v, ['pending', 'active', 'paid', 'defaulted', 'cancelled'], 'status')
    }
  }
};

function cleanPayload(definition, body, partial = false) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new HttpError(400, 'Request body must be a JSON object', 'VALIDATION_ERROR');
  hasOnly(body, definition.fields);
  if (!partial) {
    const missing = definition.required.filter((field) => body[field] === undefined);
    if (missing.length) throw new HttpError(400, `Missing required field(s): ${missing.join(', ')}`, 'VALIDATION_ERROR');
  }
  const output = {};
  for (const [field, value] of Object.entries(body)) {
    output[field] = definition.validate[field] ? definition.validate[field](value) : value;
  }
  return output;
}

function registerCrud(router, pool, name, definition) {
  router.get(`/${name}`, asyncRoute(async (req, res) => {
    const conditions = [];
    const values = [];
    if (name === 'customers' && req.query.q) {
      conditions.push('(first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)');
      const term = `%${String(req.query.q).slice(0, 100)}%`;
      values.push(term, term, term);
    }
    if (name === 'branches' && req.query.q) {
      conditions.push('(branch_code LIKE ? OR name LIKE ?)');
      const term = `%${String(req.query.q).slice(0, 100)}%`;
      values.push(term, term);
    }
    if (name === 'accounts') {
      for (const [queryName, column] of [['customerId', 'customer_id'], ['branchId', 'branch_id']]) {
        if (req.query[queryName] !== undefined) { conditions.push(`${column} = ?`); values.push(positiveId(req.query[queryName], queryName)); }
      }
      if (req.query.status !== undefined) {
        conditions.push('status = ?'); values.push(enumValue(req.query.status, ['active', 'frozen', 'closed'], 'status'));
      }
    }
    if (name === 'loans') {
      for (const [queryName, column] of [['customerId', 'customer_id'], ['branchId', 'branch_id']]) {
        if (req.query[queryName] !== undefined) { conditions.push(`${column} = ?`); values.push(positiveId(req.query[queryName], queryName)); }
      }
      if (req.query.status !== undefined) {
        conditions.push('status = ?'); values.push(enumValue(req.query.status, ['pending', 'active', 'paid', 'defaulted', 'cancelled'], 'status'));
      }
    }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [rows] = await pool.execute(`SELECT * FROM ${definition.table} ${where} ORDER BY ${definition.id} DESC`, values);
    res.json({ data: rows });
  }));
  router.post(`/${name}`, asyncRoute(async (req, res) => {
    const data = cleanPayload(definition, req.body);
    const columns = Object.keys(data);
    const [result] = await pool.execute(
      `INSERT INTO ${definition.table} (${columns.join(', ')}) VALUES (${columns.map(() => '?').join(', ')})`,
      columns.map((column) => data[column])
    );
    const [rows] = await pool.execute(`SELECT * FROM ${definition.table} WHERE ${definition.id} = ?`, [result.insertId]);
    res.status(201).json({ data: rows[0] });
  }));
  router.get(`/${name}/:id`, asyncRoute(async (req, res) => {
    const id = positiveId(req.params.id);
    const [rows] = await pool.execute(`SELECT * FROM ${definition.table} WHERE ${definition.id} = ?`, [id]);
    if (!rows.length) throw new HttpError(404, `${name.slice(0, -1)} not found`, 'NOT_FOUND');
    res.json({ data: rows[0] });
  }));
  router.patch(`/${name}/:id`, asyncRoute(async (req, res) => {
    const id = positiveId(req.params.id);
    const data = cleanPayload(definition, req.body, true);
    const columns = Object.keys(data);
    if (!columns.length) throw new HttpError(400, 'Provide at least one field to update', 'VALIDATION_ERROR');
    const [result] = await pool.execute(
      `UPDATE ${definition.table} SET ${columns.map((column) => `${column} = ?`).join(', ')} WHERE ${definition.id} = ?`,
      [...columns.map((column) => data[column]), id]
    );
    if (!result.affectedRows) throw new HttpError(404, `${name.slice(0, -1)} not found`, 'NOT_FOUND');
    const [rows] = await pool.execute(`SELECT * FROM ${definition.table} WHERE ${definition.id} = ?`, [id]);
    res.json({ data: rows[0] });
  }));
  router.delete(`/${name}/:id`, asyncRoute(async (req, res) => {
    const id = positiveId(req.params.id);
    const [result] = await pool.execute(`DELETE FROM ${definition.table} WHERE ${definition.id} = ?`, [id]);
    if (!result.affectedRows) throw new HttpError(404, `${name.slice(0, -1)} not found`, 'NOT_FOUND');
    res.status(204).end();
  }));
}

function createApp(pool) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '100kb' }));

  const router = express.Router();
  router.get('/health', asyncRoute(async (_req, res) => {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', database: 'connected' });
  }));

  for (const [name, definition] of Object.entries(resourceDefinitions)) registerCrud(router, pool, name, definition);

  router.get('/account-summary', asyncRoute(async (_req, res) => {
    const [rows] = await pool.execute('SELECT * FROM AccountSummaryView ORDER BY account_id');
    res.json({ data: rows });
  }));

  router.get('/reports/summary', asyncRoute(async (_req, res) => {
    const [[branchRows], [transactionRows], [loanRows]] = await Promise.all([
      pool.execute(`SELECT b.branch_id, b.branch_code, b.name,
          COALESCE(a.account_count, 0) AS account_count,
          COALESCE(a.total_balance, 0.00) AS total_balance,
          COALESCE(l.loan_count, 0) AS loan_count,
          COALESCE(l.principal_total, 0.00) AS principal_total
        FROM branches b
        LEFT JOIN (SELECT x.branch_id, COUNT(*) AS account_count, SUM(v.current_balance) AS total_balance
          FROM accounts x JOIN AccountSummaryView v ON v.account_id = x.account_id GROUP BY x.branch_id) a
          ON a.branch_id = b.branch_id
        LEFT JOIN (SELECT branch_id, COUNT(*) AS loan_count, SUM(principal_amount) AS principal_total
          FROM loans GROUP BY branch_id) l ON l.branch_id = b.branch_id
        ORDER BY b.name`),
      pool.execute(`SELECT transaction_type, COUNT(*) AS transaction_count, SUM(amount) AS amount_total,
          AVG(amount) AS average_amount FROM transactions WHERE status = 'posted'
        GROUP BY transaction_type ORDER BY transaction_type`),
      pool.execute(`SELECT l.status, COUNT(*) AS loan_count, SUM(l.principal_amount) AS principal_total,
          COALESCE(SUM(p.principal_paid), 0.00) AS principal_repaid,
          COALESCE(SUM(p.interest_paid), 0.00) AS interest_repaid
        FROM loans l LEFT JOIN (SELECT loan_id, SUM(CASE WHEN status = 'posted' THEN principal_paid ELSE 0 END) AS principal_paid,
          SUM(CASE WHEN status = 'posted' THEN interest_paid ELSE 0 END) AS interest_paid
          FROM loan_payments GROUP BY loan_id) p ON p.loan_id = l.loan_id
        GROUP BY l.status ORDER BY l.status`)
    ]);
    res.json({ data: { branches: branchRows, transactions: transactionRows, loans: loanRows } });
  }));

  router.get('/reports/daily-transactions', asyncRoute(async (req, res) => {
    const days = req.query.days === undefined ? 14 : Number(req.query.days);
    if (!Number.isInteger(days) || days < 1 || days > 90) throw new HttpError(400, 'days must be an integer from 1 to 90', 'VALIDATION_ERROR');
    const [rows] = await pool.execute(`SELECT DATE(occurred_at) AS transaction_date, COUNT(*) AS transaction_count,
        SUM(amount) AS amount_total FROM transactions WHERE status = 'posted'
        AND occurred_at >= DATE_SUB(CURRENT_DATE, INTERVAL ? DAY)
      GROUP BY DATE(occurred_at) ORDER BY transaction_date`, [days]);
    res.json({ data: rows });
  }));

  router.get('/transactions', asyncRoute(async (req, res) => {
    const conditions = [];
    const values = [];
    if (req.query.accountId !== undefined) {
      const id = positiveId(req.query.accountId, 'accountId');
      conditions.push('(source_account_id = ? OR destination_account_id = ?)');
      values.push(id, id);
    }
    if (req.query.type !== undefined) {
      conditions.push('transaction_type = ?');
      values.push(enumValue(req.query.type, ['deposit', 'withdrawal', 'transfer', 'loan_repayment'], 'type'));
    }
    if (req.query.status !== undefined) {
      conditions.push('status = ?');
      values.push(enumValue(req.query.status, ['pending', 'posted', 'failed', 'reversed'], 'status'));
    }
    if (req.query.from !== undefined) { conditions.push('occurred_at >= ?'); values.push(req.query.from); }
    if (req.query.to !== undefined) { conditions.push('occurred_at < ?'); values.push(req.query.to); }
    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [rows] = await pool.execute(`SELECT * FROM transactions ${where} ORDER BY occurred_at DESC`, values);
    res.json({ data: rows });
  }));
  router.get('/transactions/:id', asyncRoute(async (req, res) => {
    const id = positiveId(req.params.id);
    const [rows] = await pool.execute('SELECT * FROM transactions WHERE transaction_id = ?', [id]);
    if (!rows.length) throw new HttpError(404, 'Transaction not found', 'NOT_FOUND');
    res.json({ data: rows[0] });
  }));
  router.post('/transactions/deposit', asyncRoute(async (req, res) => {
    hasOnly(req.body, ['accountId', 'amount', 'description']);
    const result = await postDepositOrWithdrawal(pool, { ...req.body, type: 'deposit' });
    res.status(201).json({ data: result });
  }));
  router.post('/transactions/withdrawal', asyncRoute(async (req, res) => {
    hasOnly(req.body, ['accountId', 'amount', 'description']);
    const result = await postDepositOrWithdrawal(pool, { ...req.body, type: 'withdrawal' });
    res.status(201).json({ data: result });
  }));
  router.post('/transactions/transfer', asyncRoute(async (req, res) => {
    hasOnly(req.body, ['sourceAccountId', 'destinationAccountId', 'amount', 'description']);
    const result = await transferFunds(pool, req.body || {});
    res.status(201).json({ data: result });
  }));

  router.get('/loans/:id/payments', asyncRoute(async (req, res) => {
    const loanId = positiveId(req.params.id, 'loanId');
    const [rows] = await pool.execute(
      'SELECT * FROM loan_payments WHERE loan_id = ? ORDER BY paid_at DESC', [loanId]
    );
    res.json({ data: rows });
  }));
  router.get('/payments', asyncRoute(async (req, res) => {
    let rows;
    if (req.query.loanId !== undefined) {
      [rows] = await pool.execute('SELECT * FROM loan_payments WHERE loan_id = ? ORDER BY paid_at DESC', [positiveId(req.query.loanId, 'loanId')]);
    } else {
      [rows] = await pool.execute('SELECT * FROM loan_payments ORDER BY paid_at DESC');
    }
    res.json({ data: rows });
  }));
  router.get('/payments/:id', asyncRoute(async (req, res) => {
    const id = positiveId(req.params.id);
    const [rows] = await pool.execute('SELECT * FROM loan_payments WHERE loan_payment_id = ?', [id]);
    if (!rows.length) throw new HttpError(404, 'Payment not found', 'NOT_FOUND');
    res.json({ data: rows[0] });
  }));
  router.post('/payments', asyncRoute(async (req, res) => {
    hasOnly(req.body, ['loanId', 'accountId', 'principalPaid', 'interestPaid', 'description']);
    const result = await createLoanPayment(pool, req.body || {});
    res.status(201).json({ data: result });
  }));

  app.use('/api', router);
  app.use((_req, _res, next) => next(new HttpError(404, 'Route not found', 'NOT_FOUND')));
  app.use(errorHandler);
  return app;
}

module.exports = { createApp, cleanPayload, resourceDefinitions };
