# Bank Management API

Express REST API for the MySQL schema in `../bank_management.sql`. Use only with the academic sample database.

## Setup

1. Run `bank_management.sql` in MySQL 8.0+ to create and seed the `bank_management` database.
2. Copy `.env.example` to `.env` and set the database credentials.
3. Run `npm ci`.
4. Run `npm start` (default port `3001`).
5. Check `GET /api/health` to confirm the API can query MySQL.

## Routes

All routes are prefixed by `/api`. Resource collections support `GET`, `POST`, `GET /:id`, `PATCH /:id`, and `DELETE /:id` for customers, branches, accounts, and loans. Foreign key restrictions prevent deleting referenced records.

| Resource / operation | Routes |
|---|---|
| Health and account balances | `GET /health`, `GET /account-summary` |
| Aggregate reports | `GET /reports/summary`, `GET /reports/daily-transactions?days=14` |
| Customers | `GET, POST /customers`; `GET, PATCH, DELETE /customers/:id`; optional `?q=` search |
| Branches | `GET, POST /branches`; `GET, PATCH, DELETE /branches/:id`; optional `?q=` search |
| Accounts | `GET, POST /accounts`; `GET, PATCH, DELETE /accounts/:id`; filters `customerId`, `branchId`, `status` |
| Transactions | `GET /transactions`, `GET /transactions/:id`; filters `accountId`, `type`, `status`, `from`, `to` |
| Deposits / withdrawals | `POST /transactions/deposit`, `POST /transactions/withdrawal` |
| Transfers | `POST /transactions/transfer` |
| Loans | `GET, POST /loans`; `GET, PATCH, DELETE /loans/:id`; filters `customerId`, `branchId`, `status` |
| Loan payments | `GET, POST /payments`, `GET /payments/:id`, `GET /loans/:id/payments`; optional `?loanId=` on collection |

Example transfer body:

```json
{
  "sourceAccountId": 1,
  "destinationAccountId": 2,
  "amount": "25.00",
  "description": "Sample transfer"
}
```

Payment body uses `loanId`, `accountId`, and one or both of `principalPaid` and `interestPaid`. Its amount is their sum and is posted as one linked `loan_repayment` transaction.

## Financial operation behavior

Deposits, withdrawals, transfers, and loan repayments run in a MySQL transaction. Account rows are locked with `SELECT ... FOR UPDATE`; transfers acquire locks by ascending account ID, check both accounts are active, check the source balance from `AccountSummaryView`, insert a posted ledger row, then commit. Any error rolls back. Loan repayments also lock the loan, require the paying account to belong to the loan customer, and insert the payment and linked debit in the same transaction. The API uses parameter placeholders for values; dynamic SQL identifiers are fixed in server-side allowlists.

Posted transaction and payment records are read-only through this API. Use compensating/reversal workflows for corrections rather than editing ledger history. Authentication and authorization are not included in this academic phase.

## Tests

Run `npm test`. The suite exercises request validation, parameterized filtering, stable transfer lock order, successful commit, and insufficient-funds rollback with a fake pool/connection. These tests do not replace running against an actual MySQL server; configure the database and use `GET /api/health` for an integration check.
