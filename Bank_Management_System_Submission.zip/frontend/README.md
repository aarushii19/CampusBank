# Bank Management UI

React web app for the Northstar Bank academic simulation.

## Run locally

1. Set up MySQL with the root [`bank_management.sql`](../bank_management.sql) script.
2. Configure and start the Express API from [`../backend/README.md`](../backend/README.md).
3. Run `npm ci` in this directory.
4. Run `npm run dev` and open `http://localhost:5173`.

The local server serves the production bundle and proxies `/api/*` to `http://localhost:3001`. Set `API_PORT` if the backend listens on a different port. For a deployed setup, serve the `dist/` directory and route `/api` to the Express server. To use a different browser API path, set `window.BANK_API_URL` before the app bundle loads.

## Features

- Dashboard with account balance totals, transaction activity, recent ledger activity, branch summaries, and shortcuts for banking operations.
- Searchable customer directory and account register, customer creation/editing, account opening, and account status changes.
- Deposit, withdrawal, and transfer forms with account/amount validation and server-side balance checks.
- Transaction history with text, type, and status filters.
- Loan creation, portfolio summary, and loan repayment form. A repayment is posted together with its linked account debit by the backend.
- Reports supplied by MySQL aggregate endpoints for branch performance, transaction mix, and daily activity.

Financial ledger entries are not editable in the UI. The application is an academic simulation and does not include authentication or production security controls.
